const LIQUIDE_TRADE = "/trades";
const LIQUIDE_TRADE_ID = "/trades/:id";
const LIQUIDE_LOGIN = "/login";

module.exports = {
  LIQUIDE_TRADE,
  LIQUIDE_TRADE_ID,
  LIQUIDE_LOGIN,
};
