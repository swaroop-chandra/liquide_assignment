const jwt = require("jsonwebtoken");
const responseHandler = require("../utils/responseHandler");

const config = process.env;
const geneteOaToken = (users, res) => {
  const dataEnter = {
    id: users.id,
    full_name: users.full_name,
    email: users.email,
    password: users.password,
  };
  const tokenData = jwt.sign(
    dataEnter,
    config.ACCESS_TOKEN_SECRET,
    { expiresInMinutes: "60" },
    function (err, token) {
      if (err) {
        responseHandler.errorHandle(res, err);
      } else {
        res.status(200).json({
          error: false,
          token: token,
        });
      }
    }
  );
};

// const verifyOaToken = (req, res, next) => {
//   let token =
//     req.body.token || req.query.token || req.headers["x-access-token"];
//   const config = process.env;
//   if (
//     req.headers.authorization &&
//     req.headers.authorization.split(" ")[0] === "Bearer"
//   ) {
//     token = req.headers.authorization.split(" ")[1];
//   }
//   if (!token) {
//     return res.status(400).json({
//       error: true,
//       message: "A token is required for authentication",
//     });
//   }
//   try {
//     const decoded = jwt.verify(token, config.ACCESS_TOKEN_SECRET);
//     readPool.query(oa_access, [decoded.email_id], (error, oa) => {
//       if (error) {
//         responseHandler.clientError(res, error);
//       } else {
//         if (oa.length > 0) {
//           req.body["user"] = oa[0];
//           return next();
//         } else {
//           responseHandler.unAuthorised(res);
//         }
//       }
//     });
//   } catch (err) {
//     console.log(err);
//     return res.status(401).send({
//       error: true,
//       message: "Invalid Token",
//     });
//   }
// };

module.exports = {
  geneteOaToken,
  //   verifyOaToken,
};
