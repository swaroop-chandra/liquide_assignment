const liquideRouter = require("./liquide");

module.exports = { liquideRouter };
