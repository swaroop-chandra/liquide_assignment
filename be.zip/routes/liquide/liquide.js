const express = require("express");

const liquideUrl = require("../../config/url");
const { getTrades, getToken } = require("../../controller/liquide/liquideGet");
const { deleteTrades } = require("../../controller/liquide/liquidePost");

const router = express.Router();

//get
router.get(liquideUrl.LIQUIDE_LOGIN, getToken);
router.get(liquideUrl.LIQUIDE_TRADE, getTrades);

//post

//delete put patch
router.delete(liquideUrl.LIQUIDE_TRADE_ID, deleteTrades);
router.put(liquideUrl.LIQUIDE_TRADE_ID, deleteTrades);
router.patch(liquideUrl.LIQUIDE_TRADE_ID, deleteTrades);

module.exports = router;
