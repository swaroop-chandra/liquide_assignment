const responseHandler = require("../../utils/responseHandler");

const deleteTrades = (req, res, next) => {
  responseHandler.clientError(res);
};

module.exports = {
  deleteTrades,
};
