const LiquideGet = require("./liquideGet");
module.exports = {
  liquideGet,
};
