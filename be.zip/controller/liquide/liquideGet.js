const { readPool } = require("../../db/db");
const responseHandler = require("../../utils/responseHandler");

const getTrades = (req, res, next) => {
  console.log("first");
};

const getToken = (req, res) => {
  readPool.query("SELECT * FROM `login_access`", (error, tokenData) => {
    if (error) {
      responseHandler.errorHandle(res, error);
    } else {
      responseHandler.errorHandle(res, "success");
    }
  });
};

module.exports = {
  getTrades,
  getToken,
};
